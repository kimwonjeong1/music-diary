package ssafy.musicD.repository;

import ssafy.musicD.dto.MemberDto;

public interface UserRepo2 {
	public void updateUserInfo(MemberDto user);
}
